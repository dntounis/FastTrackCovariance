﻿#include <TMath.h>
#include <TGraph.h>
#include <TGraphErrors.h>
#include <TH1.h>
#include <TAxis.h>
#include <TLegend.h>
#include <TCanvas.h>
#include <TGraph.h>
#include <TString.h>
#include <TFile.h>
#include <iostream>
#include "SolGeom.h"
#include "SolTrack.h"
//
void CompRes(Double_t Ang)
{
	//
	// Available angles:
	const Int_t nAng = 8;
	Double_t theta[nAng] = { 10., 20., 30., 40., 45., 60., 75., 90. };	// angles
	Bool_t found = kFALSE; Int_t nA = -1;
	for (Int_t i = 0; i < nAng; i++)	if (Ang == theta[i])
	{
		found = kTRUE; 
		nA = i;
	}
	if (!found)
	{
		cout << "Angle not available. Choose one among the following:" << endl;
		cout << "10, 20, 30, 40, 45, 60, 75, 90" << endl;
		return;
	}
	const Int_t nPar = 5;
	TString sPar[nPar] = { "d0", "Phi", "Pt", "Theta", "Z" };
	TString sAng[nAng] = { "10deg", "20deg", "30deg", "40deg",
		"45deg", "60deg", "75deg", "90deg" };
	TString npt = "g" + sPar[2] + "-" + sAng[nA];
	TString nd0 = "g" + sPar[0] + "-" + sAng[nA];
	TString nz0 = "g" + sPar[4] + "-" + sAng[nA];
	TString nth = "g" + sPar[3] + "-" + sAng[nA];
	//
	// Input  file
	TFile *InFile = new TFile("./dump/graphs.root", "READ");
	TGraphErrors *grept = (TGraphErrors *)InFile->Get(npt);
	TGraphErrors *gred0 = (TGraphErrors *)InFile->Get(nd0);
	TGraphErrors *grez0 = (TGraphErrors *)InFile->Get(nz0);
	TGraphErrors *greth = (TGraphErrors *)InFile->Get(nth);
	//
	//	Init geometry
	//
	SolGeom *G;		// Init geometry
	const Int_t nDet = 9;
	Bool_t OK[nDet] = {		// Enable selected parts of the detector 
		1,					// Beam pipe
		1,					// Inner VTX pixel layers
		1,					// Outer VTX layers
		1,					// Drift chamber
		1,					// Barrel Si wrapper
		0,					// Barrel pre-shower
		1,					// Forw. VTX pixel layers
		1,					// Forw. Si wrapper
		0 };					// Forw. pre-shower
	G = new SolGeom(OK);
	G->Draw();
	//
	// resolution vs pt and theta
	//
	TCanvas *resol = new TCanvas("resol", "Resolutions", 100, 100, 500, 500);
	resol->Divide(2, 2);
	TGraph *grpt;			// pt resolution graphs
	TGraph *grd0;			// D resolution graphs
	TGraph *grz0;			// z0 resolution graphs
	TGraph *grth;			// theta resolution
	Double_t Npt = 100;			// Nr. of points per graph
	Double_t * pt = new Double_t[Npt];
	Double_t *spt = new Double_t[Npt];
	Double_t *sd0 = new Double_t[Npt];
	Double_t *sz0 = new Double_t[Npt];
	Double_t *sth = new Double_t[Npt];
	Double_t ptmin = 0;
	Double_t ptmax = 100;
	Double_t pts = (ptmax - ptmin) / (Double_t)Npt;
	Double_t th = TMath::Pi()*Ang / 180.;
	cout << "Th = " << th << endl;
	for (Int_t k = 0; k < Npt; k++)	// Loop on pt
	{
		Double_t x[3]; Double_t p[3];
		x[0] = 0; x[1] = 0; x[2] = 0;	// Set origin
		pt[k] = (k + 1)*pts;				// Set momentum
		p[0] = pt[k]; p[1] = 0;	p[2] = pt[k] / TMath::Tan(th);
		SolTrack *tr = new 	SolTrack(x, p, G); // Initialize track
		tr->CovCalc();			// Calculate covariance
		//spt[k] = pt[k]*tr->s_C() / (0.2998*G->B());	// Store resolutions (Dpt/pt)
		spt[k] = pt[k]*tr->s_C() * 2 / (0.2998*G->B());			// Store resolutions (Dpt/pt)
		sd0[k] = tr->s_D()*1e6;				// change to microns
		sz0[k] = tr->s_z0()*1e6;				// change to microns
		sth[k] = tr->s_ct() / (1 + pow(tr->ct(), 2));
		//sth[k] = tr->s_ct();
	}
	//
	// pt
	resol->cd(1);
	grpt = new TGraph(Npt, pt, spt);
	grpt->SetLineColor(kRed);
	grpt->SetTitle("#sigma_{pt}/pt");
	grept->SetTitle("#sigma_{pt}/pt");
	grpt->SetMinimum(0.0);
	grpt->GetXaxis()->SetTitle("pt (GeV)");
	grept->Draw("AP");
	grpt->Draw("SAME");
	// d0
	resol->cd(2);
	grd0 = new TGraph(Npt, pt, sd0);
	grd0->SetLineColor(kRed);
	grd0->SetTitle("D_{0} (#mum)");
	gred0->SetTitle("D_{0} (#mum)");
	grd0->SetMinimum(0.0);
	grd0->GetXaxis()->SetTitle("pt (GeV)");
	gred0->Draw("AP");
	grd0->Draw("SAME");
	// z0
	resol->cd(3);
	grz0 = new TGraph(Npt, pt, sz0);
	grz0->SetLineColor(kRed);
	grz0->SetTitle("Z_{0} (#mum)");
	grez0->SetTitle("Z_{0} (#mum)");
	grz0->SetMinimum(0.0);
	grz0->GetXaxis()->SetTitle("pt (GeV)");
	grez0->Draw("AP");
	grz0->Draw("SAME");
	// ct
	resol->cd(4);
	grth = new TGraph(Npt, pt, sth);
	grth->SetLineColor(kRed);
	grth->SetTitle("#theta (rad)");
	greth->SetTitle("#theta (rad)");
	grth->SetMinimum(0.0);
	grth->GetXaxis()->SetTitle("pt (GeV)");
	greth->Draw("AP");
	grth->Draw("SAME");
}